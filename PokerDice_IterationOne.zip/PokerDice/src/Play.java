import java.util.Scanner;

public class Play {
	
	static Scanner keyboard = new Scanner(System.in);

	
	public static void main(String[] args) {
		Player player1 = new Player();
		int numberOf = NumberOfOpponents();
		int nOpps = numberOf - 1;
		//System.out.println(nOpps);
		
		Player[] opponent = new Player[numberOf];
		for (int j = 0; j < opponent.length; j++){
				opponent[j] = new Player();
		}
		
		firstRoll(nOpps, player1, opponent);
		
		System.out.println("Would you like to re-roll any of your dice? (y/n) ");
	}
	
	public static int NumberOfOpponents() {
		int nPlayers;
		System.out.println("How many opponents? (1-3) ");
		while(!keyboard.hasNextInt()){
			System.out.println("Please try again.");
			System.out.println("How many opponents? (1-3) ");
			keyboard.nextLine();
		}
		nPlayers = keyboard.nextInt();
		while(nPlayers != 1 && nPlayers != 2 && nPlayers != 3){
			System.out.println("Please try again.");
			System.out.println("How many opponents? (1-3)");
			nPlayers = keyboard.nextInt();
			keyboard.nextLine();
		}
		
		return nPlayers;
	}
	public static void firstRoll(int nOpps, Player player1, Player opponent[]) {
		
		//player1.d1.roll();
		//player1.d2.roll();
		//player1.d3.roll();
		//player1.d4.roll();
		//player1.d5.roll();
		System.out.println("  Player 1: " + player1.d1.roll() + player1.d2.roll() + player1.d3.roll() + player1.d4.roll() + player1.d5.roll());
		//System.out.println("Player 1: " + player1.d1.roll() + player1.d2.roll() + player1.d3.roll() + player1.d4.roll() + player1.d5.roll());
		//System.out.println("Player 1: " + player1.d1.getFaceValue() + player1.d2.getFaceValue() + player1.d3.getFaceValue() + player1.d4.getFaceValue() + player1.d5.getFaceValue());
		//System.out.println("Player 1: " + player1.d1.getFaceValue() + player1.d2.getFaceValue() + player1.d3.getFaceValue() + player1.d4.getFaceValue() + player1.d5.getFaceValue());
		
		
		for(int x = 0; x <= nOpps; x++) {
			int number = x + 1;
			System.out.println("Opponent " + number + ": "  + opponent[nOpps].d1.roll() + opponent[nOpps].d2.roll() + opponent[nOpps].d3.roll() + opponent[nOpps].d4.roll() + opponent[nOpps].d5.roll());
			
			}
	}

}
