
public class Player {
	
	Die d1 = new Die();
	Die d2 = new Die();
	Die d3 = new Die();
	Die d4 = new Die();
	Die d5 = new Die();
	String playerName = " ";

	
	public Player() {
		
	}

}
